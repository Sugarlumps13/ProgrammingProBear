
function setup() {
  createCanvas(400, 400);
  background('#fae');
}

function draw() {
  ellipse(130,140,70,75); //ears//
  ellipse(270,140,70,75); //ears//
  fill('rgb(0,255,0)');
  stroke(255, 204, 0);
  strokeWeight(6);
  ellipse(200,200,150,130); //face//
  ellipse(200,230,100,70); //pout//
  triangle(200,200,190,210,210,210);
  circle(155,180,30);
  circle(240,180,30);}
function mousePressed() {
  background('Red')
}


  